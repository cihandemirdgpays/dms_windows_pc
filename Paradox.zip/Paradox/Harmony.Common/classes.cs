public class AnalyzeResponse
    {
        public string Token { get; set; }

        public string RequestName { get; set; }
        public string MethodName { get; set; }
        
    }


 public enum DirectionType
    {
        BOA,
        AURA,
        MIXED
    }
    
[ServiceContract(Namespace = "http://boa.net/IGate")]
    public interface IGate : IGateBase
    {
       
        [OperationContract]
        byte[] Transport(byte[] request);

          [OperationContract]
        byte[] MultipleTransport(byte[] request);

          [OperationContract]
        byte[] MultipleInternalTransport(byte[] request);

           [OperationContract]
        byte[] MultipleTransactionTransport(byte[] request);

            [OperationContract]
        byte[] Authenticate(byte[] request);

          [OperationContract]
        byte[] InternalTransport(byte[] request);

           [OperationContract]
        byte[] AuthenticationList(byte[] request);

        /// <summary>
        [OperationContract]
        byte[] FreeTransport(byte[] request);

            [OperationContract]
        byte[] WarmUp(byte[] request);

          [OperationContract(Name = "KeepConnection"), WebGet(UriTemplate = "KeepConnection", ResponseFormat = WebMessageFormat.Json)]
        void KeepConnection();

         [OperationContract]
        byte[] FileTransport(byte[] request);

          [OperationContract(Name = "TransportAsync")]
        System.Threading.Tasks.Task<byte[]> TransportAsync(byte[] request);

          [OperationContract(Name = "MultipleTransportAsync")]
        System.Threading.Tasks.Task<byte[]> MultipleTransportAsync(byte[] request);

           [OperationContract(Name = "FileTransportAsync")]
        System.Threading.Tasks.Task<byte[]> FileTransportAsync(byte[] request);

        [OperationContract]
        byte[] GetMessage(byte[] request);

    }
    
   public interface IGateBase
    {
    }

 public enum Protocols
    {
        Http,
        NetTcp
    }