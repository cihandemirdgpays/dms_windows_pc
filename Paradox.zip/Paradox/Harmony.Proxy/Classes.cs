internal class ClientFactory<T> where T : IGateBase
    {
        /// <summary>
        /// ClientFactory
        /// </summary>
        internal ClientFactory()
        {

        }


        CustomBinding customBindingTcp = null;
        EndpointAddress endPointTcp = null;

        CustomBinding customBindingHttp = null;
        EndpointAddress endPointHttp = null;

        const string Nettcp = "net.tcp";
        const string Http = "http";

        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="url"></param>
        public void Initialize(string url)
        {
            Tuple<CustomBinding, EndpointAddress> tcpResponse = GetInitializeParameters(url, Protocols.NetTcp);
            customBindingTcp = tcpResponse.Item1;
            endPointTcp = tcpResponse.Item2;

            Tuple<CustomBinding, EndpointAddress> httpResponse = GetInitializeParameters(url.Replace(Nettcp, Http), Protocols.Http);
            customBindingHttp = httpResponse.Item1;
            endPointHttp = httpResponse.Item2;
        }

        /// <summary>
        /// GetInitializeParameters
        /// </summary>
        /// <param name="url"></param>
        /// <param name="protocols"></param>
        /// <returns></returns>
        public Tuple<CustomBinding, EndpointAddress> GetInitializeParameters(string url, Protocols protocols)
        {
            DateTime start = DateTime.Now;

            CustomBinding customBinding = null;
            EndpointAddress endPoint = null;
            customBinding = new CustomBinding();
            customBinding.Name = protocols.ToString();
            customBinding.CloseTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            customBinding.OpenTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            customBinding.ReceiveTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            customBinding.SendTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);

            BinaryMessageEncodingBindingElement message = new BinaryMessageEncodingBindingElement();
            message.MaxReadPoolSize = 64;
            message.MaxWritePoolSize = 32;
            message.MaxSessionSize = 4096;
            message.ReaderQuotas = new XmlDictionaryReaderQuotas();
            message.ReaderQuotas.MaxDepth = 64;
            message.ReaderQuotas.MaxStringContentLength = 131072;
            message.ReaderQuotas.MaxArrayLength = 2147483646;
            message.ReaderQuotas.MaxBytesPerRead = 16384;
            message.ReaderQuotas.MaxNameTableCharCount = 32768;

            customBinding.Elements.Add(message);

            TransportBindingElement transport = null;
            if (protocols == Protocols.NetTcp)
                transport = GetTcpTransport();
            else
                transport = GetHttpTransport();

            customBinding.Elements.Add(transport);
            endPoint = new EndpointAddress(url);

            return new Tuple<CustomBinding, EndpointAddress>(customBinding, endPoint);
        }

        /// <summary>
        /// GetTcpTransport
        /// </summary>
        /// <returns></returns>
        private static TcpTransportBindingElement GetTcpTransport()
        {
            int connectionCount = BOA.Common.Configuration.ConfigurationManager.BOAServiceSection.BOAService.MaxTcpConnectionCount;
            TcpTransportBindingElement tcpTransport = new TcpTransportBindingElement();
            tcpTransport.ChannelInitializationTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            tcpTransport.MaxReceivedMessageSize = 2147483646;
            tcpTransport.ConnectionBufferSize = connectionCount;
            tcpTransport.MaxPendingConnections = connectionCount;
            tcpTransport.MaxPendingAccepts = connectionCount;
            tcpTransport.ListenBacklog = connectionCount;
            tcpTransport.PortSharingEnabled = false;
            tcpTransport.MaxBufferSize = 524288000;
            tcpTransport.ConnectionPoolSettings.MaxOutboundConnectionsPerEndpoint = connectionCount;
            tcpTransport.ConnectionPoolSettings.IdleTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            tcpTransport.ConnectionPoolSettings.LeaseTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            return tcpTransport;
        }

        /// <summary>
        /// GetHttpTransport
        /// </summary>
        /// <returns></returns>
        private static HttpTransportBindingElement GetHttpTransport()
        {
            int connectionCount = BOA.Common.Configuration.ConfigurationManager.BOAServiceSection.BOAService.MaxTcpConnectionCount;
            HttpTransportBindingElement httpTransport = new HttpTransportBindingElement();
            httpTransport.MaxBufferPoolSize = connectionCount;
            httpTransport.MaxBufferSize = 2147483646;
            httpTransport.MaxReceivedMessageSize = 2147483646;
            httpTransport.MaxPendingAccepts = connectionCount;
            httpTransport.RequestInitializationTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            httpTransport.TransferMode = TransferMode.Buffered;
            return httpTransport;
        }

        ChannelFactory<T> internalNetTcpFactory;
        ChannelFactory<T> internalHttpFactory;

        ChannelFactory<T> InternalFactoryNetTcp
        {
            get
            {
                if (internalNetTcpFactory == null)
                    internalNetTcpFactory = new ChannelFactory<T>(customBindingTcp, endPointTcp);
                else
                {
                    if (ExecuterParameter.Timeout.HasValue && ExecuterParameter.Timeout.Value > 300)
                    {
                        internalNetTcpFactory.Endpoint.Binding.CloseTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
                        internalNetTcpFactory.Endpoint.Binding.OpenTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
                        internalNetTcpFactory.Endpoint.Binding.ReceiveTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
                        internalNetTcpFactory.Endpoint.Binding.SendTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
                    }
                }
                return internalNetTcpFactory;
            }
        }

        /// <summary>
        /// InternalFactoryHttp
        /// </summary>
        ChannelFactory<T> InternalFactoryHttp
        {
            get
            {
                if (internalHttpFactory == null)
                {
                    internalHttpFactory = new ChannelFactory<T>(customBindingHttp, endPointHttp);
                    internalHttpFactory.Open();
                }
                return internalHttpFactory;
            }
        }

        /// <summary>
        /// GetClient
        /// </summary>
        /// <param name="isRedirection"></param>
        /// <returns></returns>
        public T GetClient(bool isRedirection = false)
        {
            if (isRedirection == false && BOA.Common.Configuration.ConfigurationManager.BOAServiceSection.BOADirectInvoke.IsActive)
            {
                //LogManager.Log("GetClient method calling with BOADirectInvoke.IsActive = true");

                return (T)BOA.Common.Helpers.DirectExecuteHelper.GetClient();
            }

            try
            {
                return GetClientTcp();
            }
            catch (Exception ex)
            {
                //LogManager.Log(ex);
                try
                {
                    return GetClientHttp();
                }
                catch (Exception exInternal)
                {
                    //LogManager.Log(exInternal);
                    return GetClientHttp();
                }
            }
        }

        private T GetClientHttp()
        {
            DateTime start = DateTime.Now;
            T client = InternalFactoryHttp.CreateChannel();
            ((IClientChannel)client).OperationTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            ((IClientChannel)client).Open(new TimeSpan(0, 0, BOA.Common.Configuration.ConfigurationManager.BOAServiceSection.BOAService.ConnectionOpenTimeout));
            //LogManager.PerformanceLog("ClientOpen", new List<Result>(), start, DateTime.Now);
            return client;
        }
        private T GetClientTcp()
        {
            //LogManager.Log("GetClientTcp process is starting..");

            DateTime start = DateTime.Now;
            T client = InternalFactoryNetTcp.CreateChannel();

            ((IClientChannel)client).OperationTimeout = new TimeSpan(0, 0, ExecuterParameter.Timeout.Value);
            ((IClientChannel)client).Open(new TimeSpan(0, 0, BOA.Common.Configuration.ConfigurationManager.BOAServiceSection.BOAService.ConnectionOpenTimeout));
            //LogManager.PerformanceLog("ClientOpen", new List<Result>(), start, DateTime.Now);

            //LogManager.Log("GetClientTcp is completed successfully.");

            return client;
        }

        /// <summary>
        /// HandleClient
        /// </summary>
        /// <param name="client"></param>
        public static void HandleClient(IGateBase client)
        {
            if (client is IClientChannel)
                try
                {
                    if (client == null)
                        return;

                    CommunicationState state = ((IClientChannel)client).State;
                    if (state == CommunicationState.Faulted)
                        ((IClientChannel)client).Abort();
                    else
                        ((IClientChannel)client).Close();

                }
                catch
                {
                    ((IClientChannel)client).Abort();
                }

            ExecuterParameter.SetTimeoutDefault();
        }

    }
    
internal class ClientFactoryInstance
    {
        static readonly object locker = new object();
        private static IDictionary<string, ClientFactory<IGate>> channelPool = new Dictionary<string, ClientFactory<IGate>>();
        private static string wcfEndpoint = ConfigurationManager.GetAppSettingsValueByName("HarmonyBoaUrl");

        private static ClientFactory<IGate> getClient()
        {  
            if (!channelPool.TryGetValue(wcfEndpoint, out ClientFactory<IGate> channelFactory))
            {
                lock (locker)
                {
                    if (!channelPool.TryGetValue(wcfEndpoint, out channelFactory))
                    {
                        channelFactory = new ClientFactory<IGate>();
                        channelFactory.Initialize(wcfEndpoint);
                        channelPool.Add(wcfEndpoint, channelFactory);
                    }
                }
            }
            return channelFactory;
        }

        public static ClientFactory<IGate> Instance
        {
            get
            {
                return   getClient();
            }
        }

       
    }
public static class CorrelationIdProvider
    {
        private static AsyncLocal<string> _correlationId = new AsyncLocal<string>();

        public static string CorrelationId
        {
            get => _correlationId.Value;
            set => _correlationId.Value = value;
        }
    }
public enum MethodType
    {
        AnalyzeTransporterRequest,
        AnalyzeAuthenticateRequest,
        AnalyzeMultipleRequest,
        AnalyzFreeTransportRequest


    }
public class Executer
    {
        public Executer()
        {
            BOA.Proxy.UserManager userManager = new BOA.Proxy.UserManager();
            var response = userManager.ServiceUserAuthenticate();
        }
        private static T MeasureExecutionTime<T>(Func<T> action, string actionName,bool logInfo =true,int requestLength =0)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();
            var result = action();
            stopwatch.Stop();
            if (logInfo)
            {
                Logger.LogInformation($"BOA {actionName} Request executed.",CorrelationIdProvider.CorrelationId, stopwatch.ElapsedMilliseconds, requestLength);
            
            }
            return result;
        }
        private static AnalyzeResponse MeasureAnalyzeRequest(byte[] request,MethodType methodType)
        {
            var analyzeResponse = new AnalyzeResponse();


            switch (methodType)
            {
                case MethodType.AnalyzeTransporterRequest:
                    analyzeResponse = WcfExecuter.AnalyzeTransporterRequest(request);
                    break;
                case MethodType.AnalyzeAuthenticateRequest:
                    analyzeResponse = WcfExecuter.AnalyzeAuthenticateRequest(request);
                    break;
                case MethodType.AnalyzeMultipleRequest:
                    analyzeResponse = WcfExecuter.AnalyzeMultipleRequest(request);
                    break;
                case MethodType.AnalyzFreeTransportRequest:
                    analyzeResponse = WcfExecuter.AnalyzFreeTransportRequest(request);
                    break;
                default:
                    break;
            }

            return analyzeResponse;

        }
        public static byte[] ExecuteTransport(byte[] request)
        {

            var correlationId = Guid.NewGuid().ToString();
            CorrelationIdProvider.CorrelationId = correlationId;
            var analyzeResponse = MeasureAnalyzeRequest(request, MethodType.AnalyzeTransporterRequest);
            var response = MeasureExecutionTime(() => WcfExecuter.TransportRequest(request), "Transport", true, request.Length);

            if (analyzeResponse.RequestName == "BOA.Types.DocumentManagement.Divit.DivitEditorRequest" && analyzeResponse.MethodName == "SelectDatabaseData2")
            {
                if (string.IsNullOrWhiteSpace(analyzeResponse.Token))
                {
                    response = BOA.Common.Helpers.EncryptionHelper.DecryptByte(response);
                }
                else
                {
                    response = BOA.Common.Helpers.EncryptionHelper.DecryptByte(response,analyzeResponse.Token);
                }
                response = BOA.Common.Helpers.CompressionHelper.DecompressBuffer(response);
                var returnObject = (ResponseBase)BOA.Common.Helpers.SerializeHelper.ByteToObject(response);
                if (!returnObject.Success)
                {
                    return response;
                }
                //returnObject.Value.FileServerDocumentList.Add(new BOA.Types.Kernel.DMS.FileServerDocument()
                //{

                //}
                //);

                var byteResponse = BOA.Common.Helpers.SerializeHelper.ObjectToByte(response);
                byteResponse = BOA.Common.Helpers.EncryptionHelper.EncryptByte(byteResponse);
                byteResponse = BOA.Common.Helpers.CompressionHelper.CompressBuffer(byteResponse);
                return byteResponse;
            }
            return response;
          
        }
        public static byte[] ExecuteAuthenticate(byte[] request)
        {
            var correlationId = Guid.NewGuid().ToString();
            CorrelationIdProvider.CorrelationId = correlationId;
            MeasureAnalyzeRequest(request,MethodType.AnalyzeAuthenticateRequest);
            var response = MeasureExecutionTime(() => WcfExecuter.Authenticate(request), "Authenticate",true,request.Length);
            return response;
        }
        public static byte[] ExecuteFreeTransport(byte[] request)
        {
            var correlationId = Guid.NewGuid().ToString();
            CorrelationIdProvider.CorrelationId = correlationId;
            MeasureAnalyzeRequest(request, MethodType.AnalyzFreeTransportRequest);
            var response = MeasureExecutionTime(() => WcfExecuter.FreeTransport(request), "FreeTransport", true, request.Length);
            return response;
        }

        public static byte[] ExecuteMultipleTransport(byte[] request)
        {
            var correlationId = Guid.NewGuid().ToString();
            CorrelationIdProvider.CorrelationId = correlationId;
            MeasureAnalyzeRequest(request, MethodType.AnalyzeMultipleRequest);
            var response = MeasureExecutionTime(() => WcfExecuter.MultipleTransport(request), "MultipleTransport", true, request.Length);
            return response;
        }
        public static byte[] ExecuteAuthenticationList(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.AuthenticationList(request), "AuthenticationList",false);
        }
        public static byte[] ExecuteFileTransport(byte[] request)
        {
          //  MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.FileTransport(request), "FileTransport",false);
        }
        public static Task<byte[]> ExecuteFileTransportAsync(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.FileTransportAsync(request), "FileTransportAsync",false);
        }      
        public static byte[] ExecuteGetMessage(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.GetMessage(request), "GetMessage",false);
        }
        public static byte[] ExecuteInternalTransport(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.InternalTransportRequest(request), "InternalTransport",false);

        }
        public static byte[] ExecuteMultipleInternalTransport(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.MultipleInternalTransport(request), "MultipleInternalTransport",false);
        }
        public static void ExecuteKeepConnection()
        {
            WcfExecuter.KeepConnection();
        }
        public static byte[] ExecuteMultipleTransactionTransport(byte[] request)
        {
           // MeasureAnalyzeRequest(request,MethodType.AnalyzeMultipleRequest);

            return MeasureExecutionTime(() => WcfExecuter.MultipleTransactionTransport(request), "MultipleTransactionTransport",false);
        }   
        public static Task<byte[]> ExecuteMultipleTransportAsync(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.MultipleTransportAsync(request), "MultipleTransportAsync",false);
        }
        public static Task<byte[]> ExecuteTransportAsync(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.TransportAsync(request), "TransportAsync",false);
        }
        public static byte[] ExecuteWarmUp(byte[] request)
        {
           // MeasureAnalyzeRequest(request);

            return MeasureExecutionTime(() => WcfExecuter.Warmup(request), "Warmup",false);
        }
        public static Stream ExecuteRest<TRequest>(TRequest request, string endpoint, HttpMethod method)
        {
            return AuraExecuter.ExecuteRequest(request, endpoint, method);
        }
        public static object ExecuteRequest(string requestId, string input = null)
        {
            return ProxyExecuter.Execute(requestId, input);
        }

    }
public class JsonMapper
    {
        public static T MapJsonToType<T>(string jsonData, Dictionary<string, string> mapping) where T : new()
        {
            var sourceData = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonData);

            if (mapping == null || sourceData == null)
                throw new ArgumentException("Geçersiz JSON formatı");

            return (T)MapObject(typeof(T), sourceData, mapping);
        }

        private static object MapObject(Type targetType, Dictionary<string, object> sourceData, Dictionary<string, string> mapping)
        {
            var result = Activator.CreateInstance(targetType) ?? throw new InvalidOperationException();

            foreach (var map in mapping)
            {
                var sourceKey = map.Key;
                var targetProperty = map.Value;
                if (!sourceData.ContainsKey(sourceKey)) continue;

                var prop = result.GetType().GetProperty(targetProperty) ?? throw new InvalidOperationException();
                if (!prop.CanWrite)
                    continue;

                var value = sourceData[sourceKey];
                var propType = prop.PropertyType;

                if (IsListType(propType))
                {
                    var itemType = propType.GetGenericArguments().First();
                    var listInstance = Activator.CreateInstance(typeof(List<>).MakeGenericType(itemType)) as IList;

                    if (value is IEnumerable<object> items)
                    {
                        foreach (var item in items)
                        {
                            var nestedMapping = mapping
                                .Where(m => m.Key.StartsWith(sourceKey + "."))
                                .ToDictionary(m => m.Key.Substring(sourceKey.Length + 1), m => m.Value);
                            var dictionary = JsonConvert.DeserializeObject<Dictionary<string, object>>(item.ToString() ?? throw new InvalidOperationException());
                            if (dictionary != null)
                            {
                                var mappedItem = MapObject(itemType, dictionary, nestedMapping);
                                listInstance?.Add(mappedItem);
                            }
                            else
                            {
                                listInstance?.Add(SafeConvert(item, itemType));
                            }
                        }
                    }

                    prop.SetValue(result, listInstance);
                }
                else if (propType.IsClass && propType != typeof(string))
                {
                    if (!(value is JObject))
                    {
                        continue;
                    }

                    var nestedMapping = mapping
                        .Where(m => m.Key.StartsWith(sourceKey + "."))
                        .ToDictionary(m => m.Key.Substring(sourceKey.Length + 1), m => m.Value);
                    var dictionary = JsonConvert.DeserializeObject<Dictionary<string, object>>(value.ToString() ?? throw new InvalidOperationException());

                   
                    var nestedObj = MapObject(propType, dictionary, nestedMapping);
                    prop.SetValue(result, nestedObj);
                }
                else
                {
                    prop.SetValue(result, SafeConvert(value, propType));
                }
            }

            return result;
        }
        
        private static bool IsListType(Type type)
        {
            return type.IsGenericType && typeof(IEnumerable).IsAssignableFrom(type);
        }
    
        //private static object SafeConvert(object value, Type targetType)
        //{
        //    if (value == null)
        //        return targetType.IsValueType ? Activator.CreateInstance(targetType) : null;

        //    try
        //    {
        //        return Convert.ChangeType(value, targetType);
        //    }
        //    catch
        //    {
        //        return Activator.CreateInstance(targetType);
        //    }
        //}

        private static object SafeConvert(object value, Type targetType)
        {
            if (value == null)
                return targetType.IsValueType ? Activator.CreateInstance(targetType) : null;

            try
            {
                // Handle nullable types
                var underlyingType = Nullable.GetUnderlyingType(targetType) ?? targetType;

                // Enum support
                if (underlyingType.IsEnum)
                {
                    if (value is string strValue)
                    {
                        return Enum.Parse(underlyingType, strValue, ignoreCase: true);
                    }

                    return Enum.ToObject(underlyingType, Convert.ChangeType(value, Enum.GetUnderlyingType(underlyingType)));
                }

                return Convert.ChangeType(value, underlyingType);
            }
            catch
            {
                return targetType.IsValueType ? Activator.CreateInstance(targetType) : null;
            }
        }
    }
public static class Logger
    {
        static Logger()
        {
            var elasticsearchUrl = ConfigurationManager.GetAppSettingsValueByName("HarmonyBoaElasticSearchPath");
            var indexFormat = "harmony-{0:yyyy.MM.dd}"; // This format will create a new index per day
          
            // Static logger setup
            Log.Logger = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .WriteTo.Console(new RenderedCompactJsonFormatter())
                .WriteTo.File(new RenderedCompactJsonFormatter(), ConfigurationManager.GetAppSettingsValueByName("HarmonyBoaLoggerPath")+ "harmonylog.json", rollingInterval: RollingInterval.Hour)
                .WriteTo.File(new RenderedCompactJsonFormatter(), ConfigurationManager.GetAppSettingsValueByName("HarmonyBoaLoggerPath")+ "harmonyerrorlog.json", rollingInterval: RollingInterval.Hour, restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Error)
                .WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(elasticsearchUrl))
                {
                    AutoRegisterTemplate = true,    // Automatically register the template
                    IndexFormat = indexFormat,     // Set the index format
                    FailureCallback = (logEvent, exception) =>
                    {
                        // Log the failure information, including both log event and exception
                        Console.WriteLine($"Failed to log event: {logEvent?.MessageTemplate}");
                        Console.WriteLine($"Exception: {exception?.Message}");
                    },
                    CustomFormatter = new Serilog.Formatting.Json.JsonFormatter() // Use JSON formatter
                })
                .CreateLogger();
        }

        public static void LogInformation(string message,string correlationId,long duration,int requestSize)
        {
            using (LogContext.PushProperty("@correlationId", correlationId))
            using (LogContext.PushProperty("@duration(ms)", duration ))
            using (LogContext.PushProperty("@requestSize(byte)",requestSize))
            {
                Log.Information(message);
            } 
        }

        public static void LogError(Exception ex, string message,string correlationId)
        {
            using (LogContext.PushProperty("@correlationId", correlationId))
            {
                Log.Error(ex, message);
            }
          
        }
    }