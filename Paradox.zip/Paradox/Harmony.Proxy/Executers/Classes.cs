internal static class AuraExecuter
   {
        public static Stream ExecuteRequest<TRequest>(TRequest requestModel, string endpoint, HttpMethod method)
        {
            var incomingRequest = WebOperationContext.Current.IncomingRequest;
            var outgoingResponse = WebOperationContext.Current.OutgoingResponse;
            
            Console.WriteLine(JsonConvert.SerializeObject(requestModel, Formatting.Indented));

            var baseUrl = ConfigurationManager.GetAppSettingsValueByName("HarmonyAuraBaseUrl");
            var fullUrl = $"{baseUrl}{endpoint}";

            using (var client = new HttpClient())
            {
                var request = new HttpRequestMessage(method, fullUrl);

                if (requestModel != null && (method == HttpMethod.Post || method == HttpMethod.Put))
                {
                    var jsonContent = JsonConvert.SerializeObject(requestModel);
                    request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                }

                var authToken = incomingRequest.Headers["Authorization"];
                if (!string.IsNullOrEmpty(authToken))
                {
                    request.Headers.Add("Authorization", authToken);
                }

                var response = client.SendAsync(request).Result;
                outgoingResponse.StatusCode = response.StatusCode;
                var responseContent = response.Content.ReadAsStringAsync().Result;

                outgoingResponse.ContentType = "application/json";

                return new MemoryStream(Encoding.UTF8.GetBytes(responseContent));
            }
        }
    }
 internal class ProxyExecuter
    {
        public static object Execute(string requestId, string input = null)
        {
            string binDirectory = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\'); // Remove trailing slash if any
            string jsonFilePath = Path.Combine(binDirectory, "boa_requests.json");

            if (!File.Exists(jsonFilePath))
                throw new FileNotFoundException($"JSON file not found: {jsonFilePath}");

            string jsonString = File.ReadAllText(jsonFilePath);
            var settings = new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver
                {
                    NamingStrategy = new DefaultNamingStrategy() // case-insensitive by default
                }
            };

            BoaRequest result = JsonConvert.DeserializeObject<BoaRequest>(jsonString, settings);
            var requestMap = result.BoaRequests.Where(x => x.Id == requestId).FirstOrDefault();
            if (requestMap == null)
            {
                return null;
            }
            var requestMock = PrepareBoaRequest(requestMap);
            if (string.IsNullOrWhiteSpace(input))
            {
                var responseObject = BOA.Proxy.Executer<RequestBase, ResponseBase>.Execute(requestMock);
                return responseObject;
            }
            else
            {
                var method = typeof(JsonMapper).GetMethod("MapJsonToType")?.MakeGenericMethod(requestMock.GetType());
                var request = method?.Invoke(null, new object[] { input, requestMap.PropertyMappings }) as RequestBase;
                request.MethodName = requestMap.MethodName;
                var responseObject = BOA.Proxy.Executer<RequestBase, ResponseBase>.Execute(request);
                return responseObject;
            }
        }
        private static RequestBase PrepareBoaRequest(BoaRequestItem boaRequest)
        {
            string requestNamespace = string.Format("{0}.{1}", boaRequest.AssemblyName, boaRequest.RequestName);
            var loadedAssemblies = AppDomain.CurrentDomain.GetAssemblies();
            var loadedAssembly = loadedAssemblies
                .FirstOrDefault(a => a.GetName().Name.Equals(boaRequest.AssemblyName));

            Assembly assembly = null;
            if (loadedAssembly != null)
            {
                assembly = loadedAssembly;
            }
            else
            {
                string binDirectory = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\'); // Remove trailing slash if any
                string dllPath = Path.Combine(binDirectory, "bin", boaRequest.AssemblyName + ".dll");
                assembly = Assembly.LoadFrom(dllPath);
            }
            if (assembly == null)
            {
                throw new Exception($"Type '{requestNamespace}' not found in assembly '{boaRequest.AssemblyName}'.");
            }

            var type = assembly.GetType(requestNamespace);

            if (type == null)
            {
                throw new Exception($"Type '{requestNamespace}' not found in assembly '{assembly.FullName}'.");
            }

            var request = Activator.CreateInstance(type) as RequestBase;
            request.MethodName = boaRequest.MethodName;

            return request;
        }


    }

 internal static class WcfExecuter
    {
        const string BOAOKBOA = "BOA-OK-BOA";
        private static Tuple<byte[], string, bool> SplitRequestForKey(byte[] request)
        {
            bool isManipulatedRequest = true;
            string addOK = BOAOKBOA;
            string addOKStr = "";

            string keyStr = "";
            int lengthIndex = request[request.Length - 35];
            byte[] headerInfo = new byte[lengthIndex];
            byte[] body = new byte[request.Length - lengthIndex - 35];
            byte[] addKeyArray = new byte[34];

            System.Buffer.BlockCopy(request, request.Length - 34, addKeyArray, 0, 34);
            try
            {
                addOKStr = BOA.Common.Helpers.SerializeHelper.ByteToObject(addKeyArray).ToString();

                if (addOK == addOKStr)
                {
                    isManipulatedRequest = true;
                }
                else
                {
                    isManipulatedRequest = false;

                    return new Tuple<byte[], string, bool>(request, "", isManipulatedRequest);
                }
            }
            catch (Exception ex)
            {
                isManipulatedRequest = false;
            }

            if (isManipulatedRequest)
            {
                System.Buffer.BlockCopy(request, request.Length - lengthIndex - 35, headerInfo, 0, lengthIndex);
                System.Buffer.BlockCopy(request, 0, body, 0, request.Length - lengthIndex - 35);
                keyStr = BOA.Common.Helpers.SerializeHelper.ByteToObject(headerInfo).ToString();

                return new Tuple<byte[], string, bool>(body, keyStr, isManipulatedRequest);
            }
            else
            {
                return new Tuple<byte[], string, bool>(request, "", false);
            }


        }
        private static Tuple<byte[],string> DecryptRequest(byte[] request)
        {
            var stopWatch = Stopwatch.StartNew();
            string token = "";
            string authKey = "";
            bool isManipulatedRequest = false;

            try
            {
                Tuple<byte[], string, bool> result = SplitRequestForKey(request);

                isManipulatedRequest = result.Item3;
                authKey = result.Item2;
                request = result.Item1; ;

                if (isManipulatedRequest)
                {
                    var tokenItems = authKey.Split('-');
                    if (!string.IsNullOrEmpty(authKey))
                    {
                        var loginRequest = new BOALoginRequest();
                        loginRequest.MethodName = "SelectByKey";
                        loginRequest.UserCode = tokenItems[0];
                        loginRequest.HostIP = tokenItems[1];
                        loginRequest.ChannelId = byte.Parse(tokenItems[2]);

                        Logger.LogInformation("IntegrationExecuter starts", CorrelationIdProvider.CorrelationId,0,0);

                        var response1 = IntegrationExecuter<BOALoginRequest, GenericResponse<BOALoginContract>>.InternalExecute(loginRequest);
                        Logger.LogInformation("IntegrationExecuter ends", CorrelationIdProvider.CorrelationId,0,0);
                        if (!response1.Success)
                        {
                            foreach (var item in response1.Results)
                            {
                                Logger.LogError(new Exception(item.Exception), item.ErrorMessage, string.Empty);
                            }
                            throw new Exception(response1.Results[0].ErrorMessage);
                        }
                        token = response1.Value.AuthenticationToken;
                    }
                }

                if (string.IsNullOrEmpty(token))
                {
                    if (isManipulatedRequest)
                    {
                        Logger.LogError(new Exception("Token Bulunamadı!"), "IsManipulatedRequest=" + isManipulatedRequest.ToString() + ",Token=" + token + ",Key=" + authKey, CorrelationIdProvider.CorrelationId);
                    }
                    else
                    {
                        request = BOA.Common.Helpers.EncryptionHelper.DecryptByte(request);
                    }
                }
                else
                {
                    request = BOA.Common.Helpers.EncryptionHelper.DecryptByte(request, token);
                }
                request = BOA.Common.Helpers.CompressionHelper.DecompressBuffer(request);

            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "IsManipulatedRequest=" + isManipulatedRequest.ToString() + ",Token=" + token + ",Key=" + authKey, CorrelationIdProvider.CorrelationId);
            }
            stopWatch.Stop();
            Logger.LogInformation($"DecryptRequest executed.", CorrelationIdProvider.CorrelationId, stopWatch.ElapsedMilliseconds, request.Length);
            return new Tuple<byte[], string>(request,token);
        }

        internal static AnalyzeResponse AnalyzeTransporterRequest(byte[] request)
        {
            var stopWatch = Stopwatch.StartNew();
            var respnse = DecryptRequest(request);
            request = respnse.Item1;
            var token = respnse.Item2;
            var transporter = (Transporter)BOA.Common.Helpers.SerializeHelper.ByteToObject(request);
            var methodName = transporter.Request.MethodName;
            stopWatch.Stop();
            Logger.LogInformation($"Method {transporter.Request.GetType().FullName} - {methodName} analyzed successfully.", CorrelationIdProvider.CorrelationId, stopWatch.ElapsedMilliseconds,request.Length);
            return new AnalyzeResponse
            {  
                RequestName = transporter.Request.GetType().FullName,
                MethodName = transporter.Request.MethodName,
                Token = token
            };
        }
        internal static AnalyzeResponse AnalyzeAuthenticateRequest(byte[] request)
        {
            var stopWatch = Stopwatch.StartNew();
            var respnse = DecryptRequest(request);
            request = respnse.Item1;
            var token = respnse.Item2;
            var transporter = (RequestBase)BOA.Common.Helpers.SerializeHelper.ByteToObject(request);
            var methodName = transporter.MethodName;
            stopWatch.Stop();
            Logger.LogInformation($"Method {transporter.GetType().FullName} - {methodName} analyzed successfully.", CorrelationIdProvider.CorrelationId, stopWatch.ElapsedMilliseconds, request.Length);
            return new AnalyzeResponse
            {
                RequestName = transporter.GetType().Namespace,
                MethodName = transporter.MethodName,
                Token = token
            };
        }
        internal static AnalyzeResponse AnalyzeMultipleRequest(byte[] request)
        {
            var stopWatch = Stopwatch.StartNew();
            var respnse = DecryptRequest(request);
            request = respnse.Item1;
            var token = respnse.Item2;
            var obj = BOA.Common.Helpers.SerializeHelper.ByteToObject(request); // authenticationRequest
            var transporter = (Transporter)BOA.Common.Helpers.SerializeHelper.ByteToObject(request);
            stopWatch.Stop();
            if (transporter.Request is BOA.Common.Types.MultipleRequest)
            {
                MultipleRequest multipleRequest = (BOA.Common.Types.MultipleRequest)transporter.Request;
                foreach (var item in multipleRequest.RequestList)
                {
                    var methodName =item.MethodName;
                    Logger.LogInformation($"Method {transporter.Request.GetType().Name} - {item.GetType().FullName} - {methodName} analyzed successfully.", CorrelationIdProvider.CorrelationId, stopWatch.ElapsedMilliseconds, request.Length);
                }
            }
            return new AnalyzeResponse
            {
                RequestName = transporter.Request.GetType().Namespace,
                MethodName = transporter.Request.MethodName,
                Token = token
            };
        }
        internal static AnalyzeResponse AnalyzFreeTransportRequest(byte[] request)
        {
            var stopWatch = Stopwatch.StartNew();
            request = DecryptRequest(request).Item1;
            var transporter = (Transporter)BOA.Common.Helpers.SerializeHelper.ByteToObject(request);
            var methodName = transporter.Request.MethodName;
            stopWatch.Stop();
            Logger.LogInformation($"Method {transporter.Request.GetType().FullName} - {methodName} analyzed successfully.", CorrelationIdProvider.CorrelationId, stopWatch.ElapsedMilliseconds, request.Length);
            return new AnalyzeResponse
            {
                RequestName = transporter.Request.GetType().Namespace,
                MethodName = transporter.Request.MethodName
            };
         }

        #region GateMethods


        internal static byte[] Authenticate(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                Logger.LogInformation("Authenticate starts", string.Empty,0,0);
                client = ClientFactoryInstance.Instance.GetClient();
                var response =  client.Authenticate(request);
                Logger.LogInformation("Authenticate ends", string.Empty, 0, 0);
                return response;                
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at Authenticate.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
            
        }
        internal static byte[] AuthenticationList(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.AuthenticationList(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at AuthenticationList.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
           
        }
        internal static byte[] TransportRequest(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.Transport(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at TransportRequest.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            } 
        }
        internal static byte[] FileTransport(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.FileTransport(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at FileTransport.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
            
        }
        internal static Task<byte[]> FileTransportAsync(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.FileTransportAsync(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at FileTransportAsync.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
           
        }
        internal static byte[] InternalTransportRequest(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.InternalTransport(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at InternalTransportRequest.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
            
        }
        internal static byte[] FreeTransport(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.FreeTransport(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at FreeTransport.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
            
        }
        internal static byte[] GetMessage(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.GetMessage(request);
            }
            catch(CommunicationException ex)
            {
                Logger.LogError(ex, "Error at GetMessage.", string.Empty);
                throw;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at GetMessage.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
            
        }
        internal static Task<byte[]> TransportAsync(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.TransportAsync(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at TransportAsync.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
           
        }
        internal static Task<byte[]> MultipleTransportAsync(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.MultipleTransportAsync(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at MultipleTransportAsync.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
        }
        internal static byte[] MultipleTransport(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.MultipleTransport(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at MultipleTransport.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
            
        }
        internal static byte[] MultipleInternalTransport(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.MultipleInternalTransport(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at MultipleInternalTransport.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
          
        }
        internal static byte[] MultipleTransactionTransport(byte[] request)
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.MultipleTransactionTransport(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at MultipleTransactionTransport.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
           
        }
        internal static void KeepConnection()
        {
            Harmony.Common.IGate client = null;
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                client.KeepConnection();
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at KeepConnection.", string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }
           
        }
        internal static byte[] Warmup(byte[] request)
        {
            Harmony.Common.IGate client = null; 
            try
            {
                client = ClientFactoryInstance.Instance.GetClient();
                return client.WarmUp(request);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error at Warmup.",string.Empty);
                throw;
            }
            finally
            {
                if (client != null)
                {
                    ClientFactory<Harmony.Common.IGate>.HandleClient(client);
                }
            }

        }
        #endregion
    }