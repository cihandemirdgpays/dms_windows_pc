 public class BoaRequestItem
    {
        public string Id { get; set; }
        public string AssemblyName { get; set; }
        public string RequestName { get; set; }
        public string MethodName { get; set; }
        public Dictionary<string, string> PropertyMappings { get; set; }
    }

    public class BoaRequest
    {
        public List<BoaRequestItem> BoaRequests { get; set; }
    }