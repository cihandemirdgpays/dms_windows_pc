
<%@ ServiceHost Language="C#" Debug="true" Service="Harmony.Wcf.Gate.BOAService" CodeBehind="BOAService.svc.cs" %>


[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class BOAService : IGate
    {
        public BOAService()
        {

        }
        public byte[] Authenticate(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteAuthenticate(request);
        }

        public byte[] AuthenticationList(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteAuthenticationList(request);
        }

        public byte[] FileTransport(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteFileTransport(request);
        }

        public Task<byte[]> FileTransportAsync(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteFileTransportAsync(request);
        }

        public byte[] FreeTransport(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteFreeTransport(request);
        }

        public byte[] GetMessage(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteGetMessage(request);
        }

        public byte[] InternalTransport(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteInternalTransport(request);
        }

        public void KeepConnection()
        {
            Harmony.Proxy.Executer.ExecuteKeepConnection();
        }

        public byte[] MultipleInternalTransport(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteMultipleInternalTransport(request);
        }

        public byte[] MultipleTransactionTransport(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteMultipleTransactionTransport(request);
        }

        public byte[] MultipleTransport(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteMultipleTransport(request);
        }

        public Task<byte[]> MultipleTransportAsync(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteMultipleTransportAsync(request);
        }

        public byte[] Transport(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteTransport(request);
        }

        public Task<byte[]> TransportAsync(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteTransportAsync(request);
        }

        public byte[] WarmUp(byte[] request)
        {
            return Harmony.Proxy.Executer.ExecuteWarmUp(request);
        }
    }

<%@ Application Codebehind="Global.asax.cs" Inherits="Harmony.Wcf.Gate.Global" Language="C#" %>
    
  [Serializable]
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            BOA.Proxy.UserManager userManager = new BOA.Proxy.UserManager();
            var response = userManager.ServiceUserAuthenticate();

            //if (!response.Success)
            //{
            //    foreach (var item in response.Results)
            //    {
            //        Logger.LogError(new Exception(item.Exception), item.ErrorCode + " " + item.ErrorMessage, Guid.NewGuid().ToString());
            //    }
            //}
            LoadAssemblies();
        }
        public void LoadAssemblies()
        {
            Logger.LogInformation("LoadAssemblies", "", 0, 0);
            AppDomain.CurrentDomain.AssemblyResolve += CurrentDomain_AssemblyResolve;
        }

        private System.Reflection.Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            string assemblyPath = Path.Combine(ConfigurationManager.AppSettings["BoaServerPath"], new AssemblyName(args.Name).Name + ".dll");
            Logger.LogInformation($"Assembly Reloaded {assemblyPath}", "", 0, 0);
            if (File.Exists(assemblyPath))
            {
                return Assembly.LoadFile(assemblyPath);
            }
            return null;
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            BOA.Proxy.UserManager userManager = new BOA.Proxy.UserManager();
            var response = userManager.ServiceUserAuthenticate();

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            BOA.Proxy.UserManager userManager = new BOA.Proxy.UserManager();
            var response = userManager.ServiceUserAuthenticate();

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }