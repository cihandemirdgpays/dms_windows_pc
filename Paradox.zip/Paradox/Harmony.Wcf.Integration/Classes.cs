 [DataContract]
    public class CompositeType
    {
       

        [DataMember(IsRequired = true)]
        public string RequestId
        {
            get;
            set;
        }

        [DataMember(IsRequired = false,EmitDefaultValue =true)]
        public string RequestBody
        {
            get;
            set;
        }
    }
    
    [ServiceContract]
    public interface IIntegrationService
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
         ResponseFormat = WebMessageFormat.Json,
         RequestFormat = WebMessageFormat.Json,
         UriTemplate = "/execute")]
        Stream Execute(CompositeType compositeType);


    }
    
    <%@ ServiceHost Language="C#" Debug="true" Service="Harmony.Wcf.Integration.IntegrationService" CodeBehind="IntegrationService.svc.cs" %>
    
    public partial class IntegrationService : IIntegrationService
    {
        public Stream Execute(CompositeType compositeType)
        {

            var response = Harmony.Proxy.Executer.ExecuteRequest(compositeType.RequestId, compositeType.RequestBody);
            var jsondata = Newtonsoft.Json.JsonConvert.SerializeObject(response);
            var responsememoryStream = new MemoryStream(Encoding.UTF8.GetBytes(jsondata));
            return responsememoryStream;
        }


    }